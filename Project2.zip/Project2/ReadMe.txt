What I have implemented
	a window showing the vertices of teapot
	press F6 to recompile shader
	center the teapot with bouding box
	right click to adjust the distance to camera
	left click to adjust the angles of camera

What I could not implemented
	None

Additional functionalities beyond project requirements
	both for OSX Yosemite and Windows 10


How to use my implementation
OSX Yosemite
1.install cmake 3.1.1 or above
2. make a build folder in Project2 folder, cd to the build folder and type cmake..
then type make
then type ./Transformations ../obj/teapot.obj

Windows10
1. Make sure you have Visual Studio 2015
2. make a build foder in Project2, cd to the build folder and type cmake .. -G "Visual Studio 14 Win64"
3. Open Transformations.sln in the build folder using VS2015
4. Set Transformations as start project
5. In project properties -> Debugging set Command Arguments to "../obj/teapot.obj"
5. Build Transformations
6. run Transformations from VS

